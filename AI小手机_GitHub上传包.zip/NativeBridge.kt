package com.ai.sxtj

import android.content.Context
import android.webkit.JavascriptInterface
import android.util.Log

/**
 * JavaScript ↔ 原生桥接
 * 前端 JS 通过 window.AndroidNative.xxx() 调用原生功能
 */
class NativeBridge(private val context: Context) {

    private val controlEngine = ControlEngine(context)
    private val voiceEngine = VoiceEngine(context)
    private val apiClient = ApiClient()

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return org.json.JSONObject().apply {
            put("battery", controlEngine.getBatteryLevel())
            put("adminActive", controlEngine.isDeviceAdminActive())
        }.toString()
    }

    @JavascriptInterface
    fun lockScreen() {
        controlEngine.lockScreen()
    }

    @JavascriptInterface
    fun setMute(enabled: Boolean) {
        controlEngine.setMute(enabled)
    }

    @JavascriptInterface
    fun speak(text: String, voiceType: String) {
        voiceEngine.speak(text, voiceType)
    }

    @JavascriptInterface
    fun stopSpeak() {
        voiceEngine.stop()
    }

    @JavascriptInterface
    fun startRecording(): String {
        return voiceEngine.startRecording() ?: ""
    }

    @JavascriptInterface
    fun stopRecording(): String {
        return voiceEngine.stopRecording() ?: ""
    }

    @JavascriptInterface
    fun callApi(apiUrl: String, apiKey: String, model: String, messagesJson: String, callbackId: String) {
        // messagesJson 是 JSON 数组字符串，格式 [[role, content], ...]
        val messages = mutableListOf<Pair<String, String>>()
        try {
            val arr = org.json.JSONArray(messagesJson)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONArray(i)
                messages.add(item.getString(0) to item.getString(1))
            }
        } catch (e: Exception) {
            Log.e("NativeBridge", "parse messages error", e)
        }

        apiClient.sendMessage(apiUrl, apiKey, model, messages) { result ->
            // 回调到 JS
            (context as? MainActivity)?.runOnUiThread {
                val js = "javascript:onApiResult('$callbackId', ${org.json.JSONObject.quote(result)})"
                (context as? MainActivity)?.webView?.evaluateJavascript(js, null)
            }
        }
    }

    @JavascriptInterface
    fun getUsageStats(): String {
        // 返回今日使用统计 JSON
        return PersonaEngine().buildUsageStats().let { stats ->
            org.json.JSONObject().apply {
                for ((app, minutes) in stats) {
                    put(app, minutes)
                }
            }.toString()
        }
    }

    @JavascriptInterface
    fun generateCheckIn(): String {
        return PersonaEngine().generateCheckInReport().let { report ->
            org.json.JSONObject().apply {
                for ((k, v) in report) {
                    put(k, v)
                }
            }.toString()
        }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
    }
}
