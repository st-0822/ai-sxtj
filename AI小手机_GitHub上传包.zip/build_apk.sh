#!/bin/bash
set -e

echo "===== 1. 创建目录结构 ====="
mkdir -p app/src/main/java/com/ai/sxtj
mkdir -p app/src/main/res/values
mkdir -p app/src/main/res/xml
mkdir -p app/src/main/assets

echo "===== 2. 移动 Kotlin 源文件 ====="
mv MainActivity.kt ApiClient.kt ControlEngine.kt PersonaEngine.kt VoiceEngine.kt WatchService.kt AdminReceiver.kt app/src/main/java/com/ai/sxtj/ 2>/dev/null || true

echo "===== 3. 移动资源文件 ====="
mv AndroidManifest.xml app/src/main/ 2>/dev/null || true
mv strings.xml app/src/main/res/values/ 2>/dev/null || true
mv device_admin.xml app/src/main/res/xml/ 2>/dev/null || true
mv Index.html app/src/main/assets/index.html 2>/dev/null || true
mv index.html app/src/main/assets/index.html 2>/dev/null || true

echo "===== 4. 生成 app/build.gradle ====="
cat > app/build.gradle <<'EOF'
apply plugin: 'com.android.application'

android {
    compileSdk 34
    namespace "com.ai.sxtj"

    defaultConfig {
        applicationId "com.ai.sxtj"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        debug { debuggable true }
        release { minifyEnabled false }
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'com.squareup.okhttp3:okhttp:4.12.0'
    implementation 'org.json:json:20231013'
}
EOF

echo "===== 5. 生成 settings.gradle ====="
echo "rootProject.name = 'ai-sxtj'" > settings.gradle
echo "include ':app'" >> settings.gradle

echo "===== 6. 检查项目结构 ====="
find . -type f | sort

echo "===== 7. 开始编译 ====="
if [ -f ./gradlew ]; then
    chmod +x ./gradlew
    ./gradlew assembleDebug
else
    gradle assembleDebug
fi

echo "===== 8. 输出 APK 路径 ====="
find . -name "*.apk" 2>/dev/null
