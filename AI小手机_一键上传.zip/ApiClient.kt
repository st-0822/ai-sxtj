package com.ai.sxtj

import android.util.Log
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object ApiClient {

    private const val TAG = "ApiClient"

    data class Config(var url: String, var key: String, var model: String)

    fun chat(config: Config, persona: String, userText: String, callback: (String) -> Unit) {
        if (config.url.isBlank() || config.key.isBlank()) {
            callback("")
            return
        }
        val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).build()
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", "你是\$persona。用符合人设的中文简短回复，不超过60字。"))
            put(JSONObject().put("role", "user").put("content", userText))
        }
        val body = JSONObject().put("model", config.model.ifBlank { "gpt-3.5-turbo" }).put("messages", messages)
        val req = Request.Builder()
            .url(config.url)
            .header("Authorization", "Bearer \${config.key}")
            .header("Content-Type", "application/json")
            .post(RequestBody.create(MediaType.get("application/json"), body.toString()))
            .build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { callback("") }
            override fun onResponse(call: Call, response: Response) {
                try {
                    val json = JSONObject(response.body()?.string() ?: "")
                    val content = json.getJSONArray("choices")
                        .getJSONObject(0).getJSONObject("message").getString("content")
                    callback(content)
                } catch (t: Throwable) { callback("") }
            }
        })
    }
}
