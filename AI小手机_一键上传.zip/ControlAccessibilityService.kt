package com.ai.sxtj

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class ControlAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 当锁定的包进入前台时，执行"返回桌面"以实现软锁屏
    }

    override fun onInterrupt() {}
}
