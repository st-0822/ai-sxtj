package com.ai.sxtj

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import org.json.JSONObject

object ControlEngine {

    fun lockScreen(context: Context): JSONObject {
        return try {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val cn = ComponentName(context, AdminReceiver::class.java)
            if (dpm.isAdminActive(cn)) {
                dpm.lockNow()
                JSONObject().put("ok", true)
            } else {
                JSONObject().put("ok", false).put("reason", "未激活设备管理员")
            }
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("reason", t.message)
        }
    }

    fun setMute(context: Context, on: Boolean): JSONObject {
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.ringerMode = if (on) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
            JSONObject().put("ok", true)
        } catch (t: Throwable) {
            JSONObject().put("ok", false)
        }
    }

    fun lockApp(context: Context, packageName: String): JSONObject {
        // 需配合 AccessibilityService 在包切换时回到桌面
        return JSONObject().put("ok", true).put("package", packageName)
    }
}
