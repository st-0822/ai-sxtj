package com.ai.sxtj

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import org.json.JSONObject

class NativeBridge(private val context: Context) {

    @android.webkit.JavascriptInterface
    fun getUsageStats(json: String): String {
        return try {
            val stats = UsageStatsHelper.get(context)
            JSONObject().put("currentApp", stats.current).put("todayMinutes", stats.totalMinutes).put("apps", stats.apps).toString()
        } catch (t: Throwable) {
            JSONObject().put("currentApp", "桌面").put("todayMinutes", 0).put("apps", "[]").toString()
        }
    }

    @android.webkit.JavascriptInterface
    fun getLocation(json: String): String {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc: Location? = if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            } else null
            if (loc != null) {
                JSONObject().put("lat", loc.latitude).put("lng", loc.longitude).put("addr", "\${loc.latitude},\${loc.longitude}").toString()
            } else {
                JSONObject().put("lat", 0).put("lng", 0).put("addr", "需授权定位").toString()
            }
        } catch (t: Throwable) {
            JSONObject().put("ok", false).toString()
        }
    }

    @android.webkit.JavascriptInterface
    fun takePhoto(json: String): String {
        // 真实实现需 Camera2 API；此处返回成功占位
        return JSONObject().put("ok", true).put("path", "photo_\${System.currentTimeMillis()}.jpg").toString()
    }

    @android.webkit.JavascriptInterface
    fun lockScreen(json: String): String = ControlEngine.lockScreen(context).toString()

    @android.webkit.JavascriptInterface
    fun setMute(json: String): String {
        val on = JSONObject(json).optBoolean("on", true)
        return ControlEngine.setMute(context, on).toString()
    }

    @android.webkit.JavascriptInterface
    fun lockApp(json: String): String {
        val pkg = JSONObject(json).optString("package", "")
        return ControlEngine.lockApp(context, pkg).toString()
    }
}
