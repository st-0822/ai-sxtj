package com.ai.sxtj

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object PersonaEngine {

    private const val PREFS = "ai_phone_persona"

    fun current(context: Context): String {
        return prefs(context).getString("persona", "温柔年上男友，宠溺，会照顾人") ?: "温柔年上男友"
    }

    fun save(context: Context, persona: String) {
        prefs(context).edit().putString("persona", persona).apply()
    }

    fun rules(context: Context): JSONArray {
        return try { JSONArray(prefs(context).getString("rules", "[]") ?: "[]") } catch (t: Throwable) { JSONArray() }
    }

    fun addRule(context: Context, trigger: String, reply: String) {
        val arr = rules(context)
        arr.put(JSONObject().put("trigger", trigger).put("reply", reply))
        prefs(context).edit().putString("rules", arr.toString()).apply()
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
