# AI 小手机 · GitHub 上传指南

## 这个包里每一个文件，都是「最终正确版本」，你**不用改任何东西**。

## 上传方式（二选一）

### 方式 A：网页一个个新建（手机适用）
仓库里点「添加文件 → 新建文件」，把下表的「文件路径」**原样填进文件名框**，把对应文件内容**整段复制粘贴**进编辑区，提交。

### 方式 B：电脑 Git 推（推荐，一次搞定）
把 `project/` 目录下所有内容，连目录结构一起拖进仓库根目录，然后：
```
git add . && git commit -m "init" && git push
```

## 文件清单（共 20 个，全都要传）

### ⚠️ 必须带路径（5 个）
| 文件路径 | 对应本包文件 |
|---|---|
| `.github/workflows/build.yml` | `build.yml` |
| `app/src/main/AndroidManifest.xml` | `AndroidManifest.xml` |
| `app/src/main/res/values/strings.xml` | `strings.xml` |
| `app/src/main/res/xml/device_admin.xml` | `device_admin.xml` |
| `app/src/main/res/xml/accessibility_service.xml` | `accessibility_service.xml` |

### 放仓库根目录（15 个，文件名就是右边名字）
| 文件名 | 本包文件 |
|---|---|
| `build_apk.sh` | `build_apk.sh` |
| `settings.gradle` | `settings.gradle` |
| `build.gradle` | `build.gradle`（项目级） |
| `gradle.properties` | `gradle.properties` |
| `README.md` | 本文件 |
| `MainActivity.kt` | `MainActivity.kt` |
| `ApiClient.kt` | `ApiClient.kt` |
| `ControlEngine.kt` | `ControlEngine.kt` |
| `PersonaEngine.kt` | `PersonaEngine.kt` |
| `VoiceEngine.kt` | `VoiceEngine.kt` |
| `WatchService.kt` | `WatchService.kt` |
| `AdminReceiver.kt` | `AdminReceiver.kt` |
| `NativeBridge.kt` | `NativeBridge.kt` |
| `UsageStatsHelper.kt` | `UsageStatsHelper.kt` |
| `ControlAccessibilityService.kt` | `ControlAccessibilityService.kt` |

> `index.html` 也放仓库根目录，`build_apk.sh` 会自动把它和所有 .kt 移到正确位置再编译。

## 上传完之后
1. 进仓库「行动 / Actions」
2. 点 `Build APK` 工作流 → 「运行工作流」
3. 等 10-20 分钟
4. 绿勾 → Artifacts → 下载 `app-debug-apk` → 解压得 `app-debug.apk`

## 功能
聊天(AI脑+API)、情侣空间、购物、外卖、音乐(可导入mp3)、游戏、照片(相册导入)、
管控(锁屏/静音/定位/拍照/使用统计)、查岗(定时+记录)、屏幕共享(真实UsageStats)、
语音/视频通话、录音机、设置(API/人设/声线/自定义规则)、角色。

## 说明
- 未填 API：走本地 AI 脑（离线可用，任何话都接得住）
- 填了 API（OpenAI 兼容）：走真大模型，人设生效
- 管控/查岗/定位/拍照的真实系统级能力，需在 App 内授权（设备管理员、无障碍、使用情况访问、定位、相机、麦克风）
- WebView 网页调试：`chrome://inspect`
