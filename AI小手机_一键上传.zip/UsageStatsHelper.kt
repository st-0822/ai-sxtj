package com.ai.sxtj

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit

object UsageStatsHelper {

    data class Stats(val current: String, val totalMinutes: Int, val apps: JSONArray)

    fun get(context: Context): Stats {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        if (usm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            return Stats("桌面", 0, JSONArray())
        }
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
        val start = cal.timeInMillis
        val end = System.currentTimeMillis()
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        var current = "桌面"
        var total = 0
        val arr = JSONArray()
        val foreground = usm.queryEvents(start, end)
        if (foreground != null) {
            val event = android.app.usage.UsageEvents.Event()
            while (foreground.hasNextEvent()) {
                foreground.getNextEvent(event)
                if (event.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    current = event.packageName
                }
            }
        }
        for (s in stats) {
            val mins = TimeUnit.MILLISECONDS.toMinutes(s.totalTimeInForeground).toInt()
            total += mins
            arr.put(JSONObject().put("name", s.packageName).put("min", mins))
        }
        return Stats(current, total, arr)
    }
}
