package com.ai.sxtj

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

object VoiceEngine {

    private var tts: TextToSpeech? = null

    fun init(context: Context, onReady: () -> Unit = {}) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.CHINESE
                onReady()
            }
        }
    }

    fun speak(text: String, voice: String = "gentle_male") {
        tts?.let { t ->
            val params = HashMap<String, String>().apply {
                put(TextToSpeech.Engine.KEY_PARAM_PITCH, pitchFor(voice).toString())
                put(TextToSpeech.Engine.KEY_PARAM_RATE, rateFor(voice).toString())
            }
            t.speak(text, TextToSpeech.QUEUE_FLUSH, params)
        }
    }

    private fun pitchFor(v: String) = when (v) {
        "cute_female" -> 180f; "loli" -> 220f; "royal" -> 140f; "cool_male" -> 70f
        else -> 110f
    }
    private fun rateFor(v: String) = when (v) {
        "cute_female", "loli" -> 130f; "cool_male" -> 85f
        else -> 100f
    }
}
