package com.ai.sxtj

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import org.json.JSONObject

class WatchService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("WatchService", "started")
        return START_STICKY
    }

    fun triggerWatch(context: Context, callback: (JSONObject) -> Unit) {
        // 由 AlarmManager 定时触发：拍照 + 定位 + 前台应用，汇总为查岗记录
        val record = JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("photo", "selfie_captured.jpg")
            put("location", "via_FusedLocation")
            put("foreground", "unknown")
        }
        callback(record)
    }
}
