#!/bin/bash
set -e

echo "===== 1. 目录结构 ====="
mkdir -p app/src/main/java/com/ai/sxtj
mkdir -p app/src/main/res/values
mkdir -p app/src/main/res/xml
mkdir -p app/src/main/assets

echo "===== 2. 移动源文件 ====="
SRC=__SRC__
cp "\$SRC/MainActivity.kt"        app/src/main/java/com/ai/sxtj/
cp "\$SRC/ApiClient.kt"           app/src/main/java/com/ai/sxtj/
cp "\$SRC/ControlEngine.kt"       app/src/main/java/com/ai/sxtj/
cp "\$SRC/PersonaEngine.kt"        app/src/main/java/com/ai/sxtj/
cp "\$SRC/VoiceEngine.kt"         app/src/main/java/com/ai/sxtj/
cp "\$SRC/WatchService.kt"        app/src/main/java/com/ai/sxtj/
cp "\$SRC/AdminReceiver.kt"       app/src/main/java/com/ai/sxtj/
cp "\$SRC/NativeBridge.kt"        app/src/main/java/com/ai/sxtj/
cp "\$SRC/UsageStatsHelper.kt"    app/src/main/java/com/ai/sxtj/
cp "\$SRC/ControlAccessibilityService.kt" app/src/main/java/com/ai/sxtj/

cp "\$SRC/AndroidManifest.xml"    app/src/main/
cp "\$SRC/strings.xml"            app/src/main/res/values/
cp "\$SRC/device_admin.xml"       app/src/main/res/xml/
cp "\$SRC/accessibility_service.xml" app/src/main/res/xml/
cp "\$SRC/index.html"             app/src/main/assets/

echo "===== 3. 模块 build.gradle ====="
cat > app/build.gradle <<'GROOVY'
apply plugin: 'com.android.application'

android {
    compileSdk 34
    namespace "com.ai.sxtj"

    defaultConfig {
        applicationId "com.ai.sxtj"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        debug { debuggable true }
        release { minifyEnabled false }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'com.squareup.okhttp3:okhttp:4.12.0'
    implementation 'org.json:json:20231013'
}
GROOVY

echo "===== 4. settings.gradle ====="
cat > settings.gradle <<'GROOVY'
pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories { google(); mavenCentral() }
}
rootProject.name = "ai-sxtj"
include ':app'
GROOVY

echo "===== 5. 项目级 build.gradle ====="
cat > build.gradle <<'GROOVY'
plugins {
    id 'com.android.application' version '8.2.2' apply false
    id 'org.jetbrains.kotlin.android' version '1.9.22' apply false
}
GROOVY

echo "===== 6. 结构检查 ====="
find . -type f -name "*.kt" -o -name "*.xml" -o -name "*.html" | sort

echo "===== 7. 编译 ====="
if [ -f ./gradlew ]; then
    chmod +x ./gradlew
    ./gradlew :app:assembleDebug
else
    gradle :app:assembleDebug
fi

echo "===== 8. APK ====="
find . -name "*.apk" 2>/dev/null
