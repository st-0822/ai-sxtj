# AI恋人 · 管控 App（云端编译版）

> 本项目用于 **GitHub Actions 云端编译 APK**。Android 端包含：微信/抖音/Soul 仿 UI、情侣空间、管控中心、后台管控服务（锁屏/定位/截屏入口，需运行时授权）。

## 功能说明
- **WebView 前端**：`app/src/main/assets/index.html`（聊天 / 管控 / 情侣空间 / DeepSeek 对话占位，震动用 `navigator.vibrate` 降级）
- **原生能力**：`ControlService`（前台服务）、`AdminReceiver`（设备管理员，锁屏）、定位/截屏入口
- **真实锁屏/截屏/通知监听**：需在手机「设置 → 安全 → 设备管理员 / 通知使用权 / 录屏授权」中手动开启

## 快速开始（手机即可完成）

### 1. 准备 GitHub 仓库
1. 注册 GitHub 账号（免费）
2. 新建仓库，名如 `AIControl`
3. 把本目录**所有文件**上传到仓库根目录（手机用 GitHub App / Kiwi 浏览器都能传）

### 2. 触发云端编译
- **自动**：push 到 `main` 分支即自动编译
- **手动**：进仓库 → `Actions` 标签 → 选 `Build APK` → 点 `Run workflow`

### 3. 下载 APK
编译完（约 10 分钟）→ `Actions` → 对应 run → `Artifacts` → 下载 `AIControl-debug-apk`（内含 `app-debug.apk`）

### 4. 手机安装
- 允许「未知来源安装」→ 点 APK 安装
- 若已装旧版（签名不同），先卸载旧版

## 目录结构
```
cloud-build/
├── .github/workflows/build.yml   # GitHub Actions 构建配置（核心）
├── build.gradle                   # 根 Gradle
├── settings.gradle
├── gradle/wrapper/                # Gradle Wrapper
├── app/
│   ├── build.gradle               # 模块 Gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/ailover/app/  # Java 源码
│       ├── assets/index.html      # WebView 前端
│       └── res/                   # 布局/资源
└── README.md
```

## 注意
- `HttpUtil.BASE` 默认 `https://your-server.com`，接入后端时改成你的地址
- 本项目仅用于**情侣间相互知情、自己设备测试**，切勿用于监控他人设备
