package com.ailover.app;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * 设备管理员接收器（锁屏/重置密码等需激活此权限）
 */
public class AdminReceiver extends DeviceAdminReceiver {
    @Override
    public void onEnabled(Context context, Intent intent) {
        Toast.makeText(context, "设备管理员已激活", Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onDisabled(Context context, Intent intent) {
        Toast.makeText(context, "设备管理员已停用", Toast.LENGTH_SHORT).show();
    }
}
