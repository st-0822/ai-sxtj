package com.ailover.app;

import android.app.Application;

/**
 * 全局上下文：保存当前登录用户 & 恋人信息（演示用，真实项目存本地数据库/后端）
 */
public class App extends Application {

    public static User currentUser;
    public static User loverUser;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public static class User {
        public String phone;
        public String name;
        public User(String phone, String name) {
            this.phone = phone;
            this.name = name;
        }
    }
}
