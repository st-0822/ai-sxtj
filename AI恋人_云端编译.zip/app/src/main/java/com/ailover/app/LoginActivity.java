package com.ailover.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

/**
 * 登录页（演示：任意手机号+密码即可登录）
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText etPhone = findViewById(R.id.et_phone);
        EditText etPwd = findViewById(R.id.et_pwd);

        findViewById(R.id.btn_login).setOnClickListener(v -> {
            if (TextUtils.isEmpty(etPhone.getText())) {
                etPhone.setError("请输入手机号");
                return;
            }
            App.currentUser = new App.User(etPhone.getText().toString(), "我");
            // 演示：默认绑定一个恋人
            App.loverUser = new App.User("13100001111", "宝贝");
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        findViewById(R.id.tv_to_register).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }
}
