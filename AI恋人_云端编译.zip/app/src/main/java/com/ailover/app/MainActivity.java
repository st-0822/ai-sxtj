package com.ailover.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.control.ControlCenterActivity;
import com.ailover.app.wechat.ChatListActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * 主界面：底部 Tab（微信 / 抖音 / Soul / 管控中心）
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnNavigationItemSelectedListener(this::onTab);
        // 默认选中「管控中心」Tab
        nav.setSelectedItemId(R.id.tab_control);
    }

    private boolean onTab(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.tab_wechat) {
            startActivity(new Intent(this, ChatListActivity.class));
            return true;
        } else if (id == R.id.tab_control) {
            startActivity(new Intent(this, ControlCenterActivity.class));
            return true;
        } else if (id == R.id.tab_couple) {
            startActivity(new Intent(this, com.ailover.app.control.CoupleSpaceActivity.class));
            return true;
        }
        return true;
    }
}
