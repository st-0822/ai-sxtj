package com.ailover.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

/**
 * 注册页（演示：直接注册并登录）
 */
public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etPhone = findViewById(R.id.et_phone);
        EditText etPwd = findViewById(R.id.et_pwd);

        findViewById(R.id.btn_register).setOnClickListener(v -> {
            App.currentUser = new App.User(etPhone.getText().toString(), "我");
            App.loverUser = new App.User("13100001111", "宝贝");
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}
