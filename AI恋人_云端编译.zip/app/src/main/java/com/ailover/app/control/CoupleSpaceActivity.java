package com.ailover.app.control;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.App;
import com.ailover.app.R;

/**
 * 情侣空间：展示双方信息 + 管控状态
 */
public class CoupleSpaceActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        String me = App.currentUser != null ? App.currentUser.name : "我";
        String lover = App.loverUser != null ? App.loverUser.name : "宝贝";
        tv.setText("💕 " + me + " ❤️ " + lover + "\n\n管控服务：" +
                (com.ailover.app.service.ControlService.running ? "运行中" : "已停止"));
        setContentView(tv);
    }
}
