package com.ailover.app.douyin;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;

/**
 * 抖音直播页（占位）
 */
public class LiveActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("📹 抖音直播 · 演示");
        setContentView(tv);
    }
}
