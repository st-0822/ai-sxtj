package com.ailover.app.douyin;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;
import com.ailover.app.wechat.WebSettingsConfig;

/**
 * 抖音模块：WebView 加载前端（短视频页）
 */
public class VideoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        new WebSettingsConfig().init(wv.getSettings());
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("file:///android_asset/index.html#/douyin");
        setContentView(wv);
    }
}
