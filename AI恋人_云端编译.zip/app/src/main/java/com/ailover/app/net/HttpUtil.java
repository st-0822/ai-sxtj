package com.ailover.app.net;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 简易 HTTP 工具（演示用，真实项目建议用 OkHttp/Retrofit）
 */
public class HttpUtil {

    private static final ExecutorService pool = Executors.newSingleThreadExecutor();
    private static final Handler main = new Handler(Looper.getMainLooper());
    public static final String BASE = "https://your-server.com"; // 替换为你的后端地址

    public interface Callback {
        void onSuccess(String body);
        void onError(String msg);
    }

    public static void post(final String path, final String json, final Callback cb) {
        pool.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(BASE + path).openConnection();
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                OutputStream os = c.getOutputStream();
                os.write(json.getBytes());
                os.close();
                Scanner s = new Scanner(c.getInputStream()).useDelimiter("\\A");
                String body = s.hasNext() ? s.next() : "";
                final String r = body;
                main.post(() -> cb.onSuccess(r));
            } catch (Exception e) {
                main.post(() -> cb.onError(e.getMessage()));
            }
        });
    }

    public static String mapToJson(HashMap<String, String> map) {
        try {
            JSONObject o = new JSONObject();
            for (Map.Entry<String, String> e : map.entrySet()) o.put(e.getKey(), e.getValue());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }
}
