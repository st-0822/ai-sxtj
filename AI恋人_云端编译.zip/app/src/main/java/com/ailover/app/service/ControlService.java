package com.ailover.app.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.ailover.app.App;
import com.ailover.app.R;

/**
 * 管控后台服务：
 *  - 前台服务常驻
 *  - 接收管控指令（锁屏 / 定位 / 截屏 / 通知读取）
 *  - 真实锁屏/截屏需配合 DeviceAdmin + MediaProjection（运行时授权）
 */
public class ControlService extends Service {

    public static final String CHANNEL_ID = "control_service";
    public static boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(1, buildNotification());
        running = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String cmd = intent.getStringExtra("cmd");
            if (cmd != null) handleCommand(cmd);
        }
        return START_STICKY;
    }

    private void handleCommand(String cmd) {
        switch (cmd) {
            case "/lock":
                lockScreen();
                break;
            case "/locate":
                // 定位：通过 FusedLocationProvider / GPS 获取后上传后端
                break;
            case "/screenshot":
                // 截屏：需 MediaProjection API，需 Activity 授权后启动
                break;
            case "/notify":
                // 通知监听：NotificationListenerService 实现
                break;
        }
    }

    private void lockScreen() {
        // 真实锁屏需 DevicePolicyManager.setPasswordQuality + lockNow()
        // 此处仅演示（需要 DeviceAdmin 激活后生效）
    }

    private Notification buildNotification() {
        Intent i = new Intent(this, com.ailover.app.MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("AI恋人 · 管控服务运行中")
                .setContentText("守护中… " + (App.loverUser != null ? App.loverUser.name : ""))
                .setSmallIcon(R.drawable.ic_default_avatar)
                .setContentIntent(pi)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "管控服务",
                    NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }
}
