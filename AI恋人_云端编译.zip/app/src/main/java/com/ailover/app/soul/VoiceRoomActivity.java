package com.ailover.app.soul;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;

/**
 * Soul 语音房（占位）
 */
public class VoiceRoomActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("🎙️ Soul 语音房 · 演示");
        setContentView(tv);
    }
}
