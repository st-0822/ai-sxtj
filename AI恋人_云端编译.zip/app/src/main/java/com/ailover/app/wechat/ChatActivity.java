package com.ailover.app.wechat;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;
import com.ailover.app.wechat.WebSettingsConfig;

/**
 * 微信聊天详情：WebView 加载前端聊天页
 */
public class ChatActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        new WebSettingsConfig().init(wv.getSettings());
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("file:///android_asset/index.html#/chat");
        setContentView(wv);
    }
}
