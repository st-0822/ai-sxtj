package com.ailover.app.wechat;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;

/**
 * 微信模块：用 WebView 加载 assets 前端（聊天列表页）
 */
public class ChatListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        wv.setSettings(new WebSettingsConfig().init(wv.getSettings()));
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("file:///android_asset/index.html#/wechat");
        setContentView(wv);
    }
}
