package com.ailover.app.wechat;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;

/**
 * 微信通讯录（占位）
 */
public class ContactActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("👥 通讯录 · 演示");
        setContentView(tv);
    }
}
