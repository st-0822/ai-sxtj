package com.ailover.app.wechat;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ailover.app.R;

/**
 * 微信朋友圈（占位）
 */
public class MomentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("🌐 朋友圈 · 演示");
        setContentView(tv);
    }
}
