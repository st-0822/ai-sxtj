package com.ailover.app.wechat;

import android.webkit.WebSettings;

/**
 * WebView 通用设置（给抖音/Soul 复用）
 */
public class WebSettingsConfig {
    public WebSettings init(WebSettings s) {
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        return s;
    }
}
